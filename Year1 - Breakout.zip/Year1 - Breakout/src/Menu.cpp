//
// Created by Steven on 04/02/2022.
//

#include "Menu.h"

Menu::Menu(sf::RenderWindow &window): window(window)
{
  init();
}

Menu::~Menu()
{

}

bool Menu::init()
{
  // init Font
  if (!font.loadFromFile("Data/Fonts/OpenSans-Bold.ttf"))
  {
    std::cout << "The Font didn't load in :( \n";
  }

  mainMenuIntroText.setString("Breakout");
  mainMenuIntroText.setFont(font);
  mainMenuIntroText.setCharacterSize(100);
  mainMenuIntroText.setFillColor(sf::Color(240, 240, 240));
  mainMenuIntroText.setPosition(((window.getSize().x / 2) - (mainMenuIntroText.getGlobalBounds().width) / 2),300);

  mainMenuPlayOption.setString("Play");
  mainMenuPlayOption.setFont(font);
  mainMenuPlayOption.setCharacterSize(40);
  mainMenuPlayOption.setFillColor(sf::Color(240, 240, 240));
  mainMenuPlayOption.setPosition(((window.getSize().x / 2) - (mainMenuPlayOption.getGlobalBounds().width)),450);

  mainMenuQuitOption.setString("Quit");
  mainMenuQuitOption.setFont(font);
  mainMenuQuitOption.setCharacterSize(40);
  mainMenuQuitOption.setFillColor(sf::Color(240, 240, 240));
  mainMenuQuitOption.setPosition(((window.getSize().x / 2) + (mainMenuQuitOption.getGlobalBounds().width) * 0.5),450);

}

void Menu::update(float dt)
{

}

void Menu::render()
{
  window.draw(mainMenuIntroText);
  window.draw(mainMenuPlayOption);
  window.draw(mainMenuQuitOption);
}

void Menu::keyPressed(sf::Event event)
{
  if ((event.key.code == sf::Keyboard::A) || (event.key.code == sf::Keyboard::D))
  {
    mainMenuPlaySelected = !mainMenuPlaySelected;

    if (mainMenuPlaySelected)
    {
      mainMenuPlayOption.setString(">Play ");
      mainMenuQuitOption.setString("  Quit");
    }

    else
    {
      mainMenuPlayOption.setString("Play ");
      mainMenuQuitOption.setString(" >Quit");
    }
  }
}