
#include "Game.h"
#include <iostream>

Game::Game(sf::RenderWindow& game_window) : window(game_window)
{
  srand(time(nullptr));

  menu = new Menu(game_window);
  game_over_menu = new GameOverMenu(game_window);
  ball = new Ball(game_window);
  paddle = new Paddle(game_window);
  gem = new Gem(game_window);
}


Game::~Game()
{
  delete menu;
  delete game_over_menu;
  delete ball;
  delete paddle;
  delete gem;
}


bool Game::init()
//initialising gameplay text on screen
{
  if (!font.loadFromFile("Data/Fonts/OpenSans-Bold.ttf"))
  {
    std::cout << "The Font didn't load in :( \n";
  }

  TitleText.setString("Breakout");
  TitleText.setFont(font);
  TitleText.setCharacterSize(40);
  TitleText.setFillColor(sf::Color(240, 240, 240));
  TitleText.setPosition(30, 30);

  QuitPrompt.setString("Q to Quit");
  QuitPrompt.setFont(font);
  QuitPrompt.setCharacterSize(30);
  QuitPrompt.setFillColor(sf::Color(240, 240, 240));
  QuitPrompt.setPosition(725, 1000);

  // initialising Brick Textures
  if (
    !red_texture.loadFromFile("Data/Images/element_red_rectangle.png") ||
    !blue_texture.loadFromFile("Data/Images/element_blue_rectangle.png") ||
    !green_texture.loadFromFile("Data/Images/element_green_rectangle.png") ||
    !purple_texture.loadFromFile("Data/Images/element_purple_rectangle.png") ||
    !yellow_texture.loadFromFile("Data/Images/element_yellow_rectangle.png"))
  {
    std::cout << "A Brick Texture didn't load in :( \n";
  }

  // setting up brick grid
  for (int i = 0; i < grid_size; i++)
  {
    for (int j = 0; j < grid_size; j++)
    {
      if ((i * grid_size + j) % 5 == 0)
      {
        bricks[i * grid_size + j].addTexture(red_texture, Brick::Colour::Red);
      }

      else if ((i * grid_size + j) % 5 == 1)
      {
        bricks[i * grid_size + j].addTexture(blue_texture, Brick::Colour::Blue);
      }

      else if ((i * grid_size + j) % 5 == 2)
      {
        bricks[i * grid_size + j].addTexture(
          green_texture, Brick::Colour::Green);
      }

      else if ((i * grid_size + j) % 5 == 3)
      {
        bricks[i * grid_size + j].addTexture(
          purple_texture, Brick::Colour::Purple);
      }

      else if ((i * grid_size + j) % 5 == 4)
      {
        bricks[i * grid_size + j].addTexture(
          yellow_texture, Brick::Colour::Yellow);
      }

      bricks[i * grid_size + j].sprite.setPosition(5 + 90 * i, 100 + 50 * j);
      bricks[i * grid_size + j].sprite.setScale(1.2, 1.2);
    }
  }

  Lives_str = std::to_string(Lives);
  LivesText.setString("Lives:  " + Lives_str);
  LivesText.setFont(font);
  LivesText.setCharacterSize(30);
  LivesText.setFillColor(sf::Color(240, 240, 240));
  LivesText.setPosition(30, 1000);

  return true;
}


void Game::update(float dt)
{
  switch (current_state)
  {
    case gameplay:
    {
      game_over_menu->update(dt);
      paddle->update(dt);
      ball->update(dt);
      gem->update(dt);

      Lives_str = std::to_string(Lives);
      LivesText.setString("Lives:  " + Lives_str);

      // ball respawn
      if (
        ball->ball.getPosition().y >
        (window.getSize().y - ball->ball.getGlobalBounds().height))
      {
        ball->spawn();
        ball->ball_move_up = !ball->ball_move_up;

        Lives = Lives - 1;
        if (Lives == 0)
        {
          current_state = gameOver;
        }
      }

      if (gem->gem.getPosition().y > (window.getSize().y - gem->gem.getGlobalBounds().height))
      {
        gem->spawn();
      }


      // Ball/paddle collision
      if (collisionCheck(ball->ball, paddle->paddle))
      {
        ball->ball_move_up = true;
      }

      // ball/brick collision
      for (int i = 0; i < grid_size * grid_size; i++)
      {
        if (
          bricks[i].getIsVisible() &&
          collisionCheck(ball->ball, bricks[i].sprite))
        {
          ball->ball_move_up = !ball->ball_move_up;
          bricks[i].setIsVisible(false);
          game_over_menu->score = game_over_menu->score + 1;
        }

        // Paddle/Gem collision
        if (collisionCheck(paddle->paddle, gem->gem))
        {
          gem->spawn();
          Lives = Lives + 1;
        }
      }

      if (game_over_menu->score == 25)
      {
        ball->ball_speed = 275;
      }

      if (game_over_menu->score == 50)
      {
        ball->ball_speed = 300;
      }

      if (game_over_menu->score == 75)
      {
        ball->ball_speed = 325;
      }

      if (game_over_menu->score == 100)
      {
        current_state = gameOver;
      }
    }
    break;
  }
}


void Game::render()
{
  switch (current_state)
  {
    case mainMenu:
    {
      menu->render();
    }
    break;

    case gameplay:
    {
      window.draw(TitleText);
      window.draw(QuitPrompt);
      window.draw(game_over_menu->ScoreText);
      window.draw(LivesText);

      ball->render();
      paddle->render();

      for (int i = 0; i < grid_size * grid_size; i++)
      {
        if (bricks[i].getIsVisible())
        {
          window.draw(bricks[i].sprite);
        }
      }

      gem->render();
    }
    break;

    case gameOver:
    {
      game_over_menu->render();
    }
    break;
  }
}

void Game::keyPressed(sf::Event event)
{
  switch (current_state)
  {
    case mainMenu:
    {
      menu->keyPressed(event);

      if (event.key.code == sf::Keyboard::Enter)
      {
        if (menu->mainMenuPlaySelected)
        {
          current_state = gameplay;
          paddle->spawn();
          ball->spawn();
          game_over_menu->score = 0;
          ball->ball_speed      = 250;
          for (int i = 0; i < grid_size * grid_size; i++)
          {
            bricks[i].setIsVisible(true);
          }
          Lives = 3;
          gem->spawn();
        }

          else
          {
            window.close();
          }
        }
      }
      break;

      case gameplay:
      {
        paddle->keyPressed(event);

        if (event.key.code == sf::Keyboard::Q)
        {
          current_state = mainMenu;
        }
      }
      break;

      case gameOver:
      {
        game_over_menu->keyPressed(event);

        if (event.key.code == sf::Keyboard::Enter)
        {
          if (game_over_menu->gameOverPlaySelected)
          {
            current_state = gameplay;
            paddle->spawn();
            ball->spawn();
            game_over_menu->score = 0;
            ball->ball_speed = 250;
            for (int i = 0; i < grid_size * grid_size; i++)
            {
              bricks[i].setIsVisible(true);
            }
            Lives = 3;
            gem->spawn();
          }

          else
          {
            window.close();
          }
        }
      }
    break;
  }
}

void Game::keyReleased(sf::Event event)
{
  switch (current_state)
  {
    case mainMenu: {}
      break;

    case gameplay:
    {
      paddle->keyReleased(event);
    }
     break;

    case gameOver: {}
     break;
  }
}

bool Game::collisionCheck(sf::Sprite sprite1, sf::Sprite sprite2)
{
  if(
      sprite1.getPosition().x <= sprite2.getPosition().x + sprite2.getGlobalBounds().width &&
      sprite1.getPosition().x + sprite1.getGlobalBounds().width >= sprite2.getPosition().x &&
      sprite1.getPosition().y <= sprite2.getPosition().y + sprite2.getGlobalBounds().height &&
      sprite1.getPosition().y + sprite1.getGlobalBounds().height >= sprite2.getPosition().y)
  {
    return true;
  }

}


void Game::mouseClicked(sf::Event event)
{
  // get the click position
  sf::Vector2i click = sf::Mouse::getPosition(window);
}
