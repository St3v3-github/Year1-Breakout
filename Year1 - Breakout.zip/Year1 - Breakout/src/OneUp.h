//
// Created by Steven on 04/02/2022.
//

#ifndef BREAKOUTSFML_ONEUP_H
#define BREAKOUTSFML_ONEUP_H
#include <iostream>
#include <SFML/Graphics.hpp>

class OneUp
{
 public:

  OneUp();

  sf::Sprite sprite;

  void addTexture(sf::Texture& texture);

  bool getIsVisible();
  void setIsVisible(bool value);

 private:
  bool is_visible = true;


};

#endif // BREAKOUTSFML_ONEUP_H
