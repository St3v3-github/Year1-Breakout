//
// Created by Steven on 04/02/2022.
//

#ifndef BREAKOUTSFML_MENU_H
#define BREAKOUTSFML_MENU_H

#include <SFML/Graphics.hpp>
#include <iostream>

class Menu
{
 public:
  Menu(sf::RenderWindow &window);
  ~Menu();

  bool init();
  void update(float dt);
  void render();
  void keyPressed(sf::Event event);

  bool mainMenuPlaySelected = true;

  sf::RenderWindow&window;

  sf::Font font;
  sf::Text mainMenuIntroText;
  sf::Text mainMenuPlayOption;
  sf::Text mainMenuQuitOption;


};

#endif // BREAKOUTSFML_MENU_H
