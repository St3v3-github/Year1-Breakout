//
// Created by Steven on 04/02/2022.
//

#ifndef BREAKOUTSFML_PADDLE_H
#define BREAKOUTSFML_PADDLE_H

#include <SFML/Graphics.hpp>
#include <iostream>

class Paddle
{
 public:
  Paddle(sf::RenderWindow &window);
  ~Paddle();

  bool init();
  void update(float dt);
  void render();
  void keyPressed(sf::Event event);
  void keyReleased(sf::Event event);
  void spawn();

  sf::RenderWindow &window;

  float paddle_speed = 500;

  sf::Sprite paddle;
  sf::Texture paddle_texture;
  sf::Vector2f paddle_direction = {0,0};

  bool is_on_left;
};

#endif // BREAKOUTSFML_PADDLE_H
