//
// Created by Steven on 04/02/2022.
//

#include "Paddle.h"

Paddle::Paddle(sf::RenderWindow &window): window(window)
{
  init();
}

Paddle::~Paddle()
{

}

bool Paddle::init()
{
  //init red_paddle
  if (!paddle_texture.loadFromFile("Data/Images/paddleRed.png"))
  {
    std::cout << "The Red Paddle Texture didn't load in :( \n";
  }
  paddle.setTexture(paddle_texture);
  paddle.setScale(1.2,1);
  paddle.setPosition(400, 900);

  return true;
}

void Paddle::update(float dt)
{
  if (paddle.getPosition().x > (window.getSize().x - paddle.getGlobalBounds().width))
  {
    paddle.move(-2 * paddle_speed * dt, 0);
  }

  if (paddle.getPosition().x < 0)
  {
    paddle.move(2 * paddle_speed * dt, 0);
  }

  else
  {
    paddle.move(paddle_direction.x * paddle_speed * dt, 0);
  }
}

void Paddle::render()
{
  window.draw(paddle);
}

void Paddle::keyPressed(sf::Event event)
{
  if (event.key.code == sf::Keyboard::A)
  {
     paddle_direction.x = -1;
  }

  if (event.key.code == sf::Keyboard::D)
  {
    paddle_direction.x = 1;
  }
}

void Paddle::keyReleased(sf::Event event)
{
  if ((event.key.code == sf::Keyboard::A) || (event.key.code == sf::Keyboard::D))
  {
    paddle_direction.x = 0;
  }
}

void Paddle::spawn()
{
  paddle.setPosition(400, 900);
}