//
// Created by Steven on 04/02/2022.
//

#ifndef BREAKOUTSFML_SCORE_H
#define BREAKOUTSFML_SCORE_H

class Score
{
};

#endif // BREAKOUTSFML_SCORE_H
