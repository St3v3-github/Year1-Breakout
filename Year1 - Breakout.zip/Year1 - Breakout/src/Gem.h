//
// Created by Steven on 16/02/2022.
//

#ifndef BREAKOUTSFML_GEM_H
#define BREAKOUTSFML_GEM_H
#include <iostream>
#include <SFML/Graphics.hpp>

class Gem
{
 public:
  Gem(sf::RenderWindow &window);
  ~Gem();

  bool init();
  void update(float dt);
  void render();
  void spawn();

  sf::RenderWindow &window;

  sf::Sprite gem;
  sf::Texture gem_texture;

  float gem_speed = 250;
  bool gem_move_down = true;

  float random_x = 0;

};


#endif // BREAKOUTSFML_GEM_H
