//
// Created by Steven on 16/02/2022.
//

#include "Gem.h"

Gem::Gem(sf::RenderWindow& window):window(window)
{
init();
srand(time(nullptr));
}

Gem::~Gem()
{

}

bool Gem::init()
{
  if (!gem_texture.loadFromFile("Data/Images/element_purple_diamond_glossy.png"));
  {
    std::cout << "The Gem Texture didn't load in :( \n";
  }
  gem.setTexture(gem_texture);
  gem.setPosition(window.getSize().x /2 - gem.getGlobalBounds().width / 2 , -7500);

  return true;
}

void Gem::update(float dt)
{
  if (gem_move_down)
  {
    gem.move(0,1.0f * gem_speed * dt);
  }
}

void Gem::render()
{
  window.draw(gem);
}


void Gem::spawn()
{
  gem_move_down = true;
  random_x = std::rand() % int(window.getSize().x - gem.getGlobalBounds().width);
  gem.setPosition(random_x, -7500);
}

