//
// Created by Steven on 04/02/2022.
//

#include "OneUp.h"

OneUp::OneUp()
{
}

void OneUp::addTexture(sf::Texture& texture)
{
  sprite.setTexture(texture);
}

void OneUp::setIsVisible(bool value)
{
  is_visible = value;
}


bool OneUp::getIsVisible()
{
  return is_visible;
}

