//
// Created by Steven on 04/02/2022.
//

#ifndef BREAKOUTSFML_BRICK_H
#define BREAKOUTSFML_BRICK_H
#include <iostream>
#include <SFML/Graphics.hpp>

class Brick
{
 public:

  Brick();

  enum Colour {Red, Blue, Green, Purple, Yellow};
  sf::Sprite sprite;

  void addTexture(sf::Texture& texture, Colour texture_colour);

  bool getIsVisible();
  void setIsVisible(bool value);

 private:
  Colour colour;
  bool is_visible = true;



};
#endif // BREAKOUTSFML_BRICK_H
