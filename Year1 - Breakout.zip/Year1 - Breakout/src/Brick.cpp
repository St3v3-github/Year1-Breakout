//
// Created by Steven on 04/02/2022.
//

#include "Brick.h"

Brick::Brick()
{
  colour = Colour::Red;
}

void Brick::addTexture(sf::Texture& texture, Colour texture_colour)
{
  sprite.setTexture(texture);
  colour = texture_colour;
}

void Brick::setIsVisible(bool value)
{
  is_visible = value;
}


bool Brick::getIsVisible()
{
  return is_visible;
}

