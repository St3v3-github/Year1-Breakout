//
// Created by Steven on 04/02/2022.
//

#ifndef BREAKOUTSFML_BALL_H
#define BREAKOUTSFML_BALL_H
#include <iostream>
#include <SFML/Graphics.hpp>

class Ball
{
   public:
    Ball(sf::RenderWindow &window);
    ~Ball();

    bool init();
    void update(float dt);
    void render();
    void spawn();

    sf::RenderWindow &window;

    sf::Sprite ball;
    sf::Texture ball_texture;

    float ball_speed = 250;
    bool ball_move_up = true;
    bool ball_move_right = true;
  };

#endif // BREAKOUTSFML_BALL_H
