//
// Created by Steven on 04/02/2022.
//

#include "Ball.h"

Ball::Ball(sf::RenderWindow &window): window(window)
{
  init();
}

Ball::~Ball()
{

}

bool Ball::init()
{
  if (!ball_texture.loadFromFile("Data/Images/ballGrey.png"))
  {
    std::cout << "The Ball Texture didn't load in :( \n";
  }
  ball.setTexture(ball_texture);
  ball.setScale(1.5, 1.5);
  ball.setPosition(450,850);

  return true;
}

void Ball::update(float dt)
{
  if (ball_move_up)
  {
    ball.move(0,-1.0f * ball_speed * dt);
  }

  else
  {
    ball.move(0,1.0f * ball_speed * dt);
  }


  if (ball.getPosition().y < 0)
  {
    ball_move_up = !ball_move_up;
  }

  if (ball_move_right)
  {
    ball.move(1.2f * ball_speed * dt, 0);
  }

  else
  {
    ball.move(-1.2f * ball_speed * dt, 0);
  }

  if ((ball.getPosition().x > window.getSize().x - ball.getGlobalBounds().width) || (ball.getPosition().x < 0))
  {
    ball_move_right = !ball_move_right;
  }

}

void Ball::render()
{
  window.draw(ball);
}

void Ball::spawn()
{
  ball.setPosition(450,850);
}