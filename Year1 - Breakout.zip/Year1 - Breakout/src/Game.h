
#ifndef BREAKOUT_GAME_H
#define BREAKOUT_GAME_H

#include "Ball.h"
#include "Brick.h"
#include "GameOverMenu.h"
#include "Gem.h"
#include "Menu.h"
#include "OneUp.h"
#include "Paddle.h"
#include "Vector2.h"
#include <SFML/Graphics.hpp>

class Game
{
 public:
  Game(sf::RenderWindow& window);
  ~Game();
  bool init();
  void update(float dt);
  void render();
  void keyPressed(sf::Event event);
  void keyReleased(sf::Event event);
  bool collisionCheck(sf::Sprite sprite1, sf::Sprite sprite2);
  void mouseClicked(sf::Event event);

  enum StateEnum
  {
    mainMenu,
    gameplay,
    gameOver
  };

  StateEnum current_state;

 private:
  sf::RenderWindow& window;

  sf::Font font;
  sf::Text TitleText;
  sf::Text QuitPrompt;

  Menu *menu = nullptr;
  GameOverMenu *game_over_menu = nullptr;
  Ball *ball = nullptr;
  Paddle *paddle = nullptr;
  Gem * gem = nullptr;

  //brick things
  int grid_size = 10;
  Brick bricks [100];
  sf::Texture red_texture;
  sf::Texture blue_texture;
  sf::Texture green_texture;
  sf::Texture purple_texture;
  sf::Texture yellow_texture;

  int Lives = 3;
  sf::Text LivesText;
  std::string Lives_str;
};

#endif // BREAKOUT_GAME_H