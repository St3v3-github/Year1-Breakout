# breakout-21-22-St3v3-github
breakout-21-22-St3v3-github created by GitHub Classroom

Hi Lindsey and Tom, Here's the ReadMe for my Breakout Submission.
The branch the Submission is in is HavingAnotherGo, I decided to branch it early on after an initial attempt wasn't great.
Final push is titled Final Submission.

Controls are as follows:
  A - Move Paddle Left
  D - Move Paddle Right
  Enter - Select Option
  
The Win condition for the game is destroying all the blocks and Reaching 100 points.
Falling Gems can be collected for extra Lives.

Hope you Have Fun :)
